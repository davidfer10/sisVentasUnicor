<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/


Route::get('/', function () {
    return Redirect::to('almacen/categoria');
});

Route::get('/almacen/datosgov', function () {
    return view("almacen.datos.datosgov");
});

Route::get('/almacen/datosgovprecio', function () {
    return view("almacen.datos.datosgovprecio");
});

Route::get('/almacen/datosgovcantidad', function () {
    return view("almacen.datos.datosgovcantidad");
});


Route::resource('almacen/categoria','CategoriaController');
Route::resource('almacen/articulo','ArticuloController');

