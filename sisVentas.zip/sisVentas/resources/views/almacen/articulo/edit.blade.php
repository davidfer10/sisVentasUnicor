@extends ('layouts.admin')
@section ('contenido')
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
			<h3>Editar Articulo: {{ $articulo->nombre}}</h3>
			@if (count($errors)>0)
			<div class="alert alert-danger">
				<ul>
				@foreach ($errors->all() as $error)
					<li>{{$error}}</li>
				@endforeach
				</ul>
			</div>
			@endif

			{!!Form::model($articulo,['method'=>'PATCH','route'=>['almacen.articulo.update',$articulo->idarticulo]])!!}
            {{Form::token()}}



			<div class="form-group">
				<label for="idcategoria">Categoria</label>
				<select class="form-control" name="idcategoria" id="idcategoria">
					<option value=" ">Selecciona</option>
					@foreach ($categorias as $e)
					<option value="{{$e->idcategoria}}">{{$e->nombre}}</option>
					
				@endforeach
				</select>
			</div>

			<div class="form-group">
            	<label for="nombre">Codigo</label>
            	<input type="text" name="codigo" class="form-control" value="{{$articulo->codigo}}" placeholder="Codigo...">
            </div>
            <div class="form-group">
            	<label for="nombre">Nombre</label>
            	<input type="text" name="nombre" class="form-control" value="{{$articulo->nombre}}" placeholder="Nombre...">
            </div>

			<div class="form-group">
            	<label for="nombre">Stock</label>
            	<input type="text" name="stock" class="form-control" value="{{$articulo->stock}}" placeholder="Stock...">
            </div>

            <div class="form-group">
            	<label for="descripcion">Descripción</label>
            	<input type="text" name="descripcion" class="form-control" value="{{$articulo->descripcion}}" placeholder="Descripción...">
            </div>

			<div class="form-group">
            	<label for="imagen">Imagen</label>
            	<input type="file" name="imagen" class="form-control" >
            </div>

            <div class="form-group">
            	<button class="btn btn-primary" type="submit">Guardar</button>
            	<button class="btn btn-danger" type="reset">Cancelar</button>
            </div>

			{!!Form::close()!!}		
            
		</div>
	</div>
@endsection