@extends ('layouts.admin')
@section ('contenido')



		<div class="container">
<br>






<?php

   $url="https://www.datos.gov.co/resource/kfq5-ygdu.json";

$json= file_get_contents($url);

$datos= json_decode($json, true);





    ?>

    <div class="col-md-4">

    

     
                                    
                          	
				<select class="form-control" name="producto" id="producto">
					<option value=" ">Selecciona una Producto</option>
					@foreach ($datos as $e)
					<option value="{{$e['producto']}}/{{$e['cantidad']}}">{{$e['producto']}}</option>
					
				@endforeach
				</select>
			</div>

        <div class="col-md-4">
				
				<select class="form-control" name="cantidad" id="cantidad">
					<option value=" ">Selecciona un Producto</option>
					@foreach ($datos as $e)
					<option value="{{$e['producto']}}/{{$e['cantidad']}}">{{$e['producto']}}</option>
					
				@endforeach
				</select>
			</div>

       <div class="col-md-3">
            	<button class="btn btn-primary"  id="boton" onClick="graficar()" type="submit">Graficar</button>
            </div>

   
                       


		
            <br>
            <br>
            <br>
            <br>

      <div  id="piechart">
 </div>
		<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>


<script type="text/javascript">

function graficar(){ 
      var datos1=document.getElementById('producto').value;
      var datos2=document.getElementById('cantidad').value;

      var vecdatos1=datos1.split("/");
       var vecdatos2=datos2.split("/");



      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {

            var data = google.visualization.arrayToDataTable([
          ['Producto', 'Cantidad'],
         [ vecdatos1[0],Number(vecdatos1[1]) ],
                     [vecdatos2[0],Number(vecdatos2[1])]

          
        ]);

        var options = {
          title: 'Grafica comparacion de Producto y su cantidad '
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
      }
    </script>


	
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="table-responsive">
			<table class="table table-striped table-bordered table-condensed table-hover">
                <thead>
                <tr>
                <th>Tipo Producto</th>
                    <th>Producto </th>
                    <th>Presentacion</th>
                    <th>Cantidad</th>
                    <th>Unidad</th>
                    <th>Precio Calidad Extra</th>
                    <th>Precio Calidad Primera</th>
				
                </tr>
                </thead>
                <tbody>
                <?php
$j=1;
            foreach ($datos as $key) {
			
                 echo '<tr>';
                    echo '<td>'. $key['tipoproducto'] . '</td>';
                    echo '<td>'. $key['producto'] . '</td>';
                    echo '<td>'. $key['presentacion'] . '</td>';
                    echo '<td>'. $key['cantidad'] . '</td>';
                     echo '<td>'. $key['unidad'] . '</td>';
                    echo '<td>'. $key['preciocalidadextra'] . '</td>';
                    echo '<td>'. $key['preciocalidadprimera'] . '</td>';
					



                    echo '</tr>' ;
                    $j++;
if($j==20) break;
               
            }

              ?>
                </tbody>
            </table>
</div>
</div>

 </div>

@endsection