<?php $__env->startSection('contenido'); ?>


    

		<div class="container">




<div style="width:90%">
 <div class="col s12" style="high:200px" >
        <canvas id="chart1" class="col s12 m12" ></canvas>
    </div>
 </div>
 
 <br>
<br>

<?php

   $url="https://www.datos.gov.co/resource/kfq5-ygdu.json";

$json= file_get_contents($url);

$datos= json_decode($json, true);





    ?>
<script type="text/javascript" src="../js/Chart.js"></script>
	 <script type="text/javascript">

   

   

    var lineChartData = {
			labels : [
                 <?php
                 $k=0;
                foreach ($datos as $key) {
                    echo '"'.$key["producto"].'"';?>,
               <?php 
               $k++;
               if($k==10) break;
               }
                ?>
            ],
			datasets : [
				{
				 label: "My First dataset",
            fillColor : '#f54242',
            strokeColor: "rgba(220,220,220,1)",
            pointColor: "rgba(220,220,220,1)",
            pointStrokeColor: "#000",
            pointHighlightFill: "#000",
            pointHighlightStroke: "rgba(220,220,220,1)",

					data : [
                         <?php
                         $l=0;
                foreach ($datos as $key) {
                    echo $key['preciocalidadextra'];?>,
                <?php 
                $l++;
               if($l==10) break;}
                ?>
                    ],

                    	
                    
				},

        	{
				 label: "My First dataset",
            
           fillColor : "rgba(151,187,205,0.2)",
					strokeColor : "rgba(151,187,205,1)",
					pointColor : "rgba(151,187,205,1)",
					pointStrokeColor : "#fff",
					pointHighlightFill : "#fff",
					pointHighlightStroke : "rgba(151,187,205,1)",

					data : [
                         <?php
                         $l=0;
                foreach ($datos as $key) {
                    echo $key['preciocalidadprimera'];?>,
                <?php 
                $l++;
               if($l==10) break;}
                ?>
                    ],

                    	
                    
				},

			]

		}

   


		var ctx = document.getElementById("chart1").getContext("2d");
		window.myLine = new Chart(ctx).Line(lineChartData, {
			showScale: false,
        	pointDot : true,
            responsive: true
		});

    



    </script>

	
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="table-responsive">
			<table class="table table-striped table-bordered table-condensed table-hover">
                <thead>
                <tr>
                <th>Tipo Producto</th>
                    <th>Producto </th>
                    <th>Presentacion</th>
                    <th>Cantidad</th>
                    <th>Unidad</th>
                    <th>Precio Calidad Extra</th>
                    <th>Precio Calidad Primera</th>
				
                </tr>
                </thead>
                <tbody>
                <?php
$j=1;
            foreach ($datos as $key) {
			
                 echo '<tr>';
                    echo '<td>'. $key['tipoproducto'] . '</td>';
                    echo '<td>'. $key['producto'] . '</td>';
                    echo '<td>'. $key['presentacion'] . '</td>';
                    echo '<td>'. $key['cantidad'] . '</td>';
                     echo '<td>'. $key['unidad'] . '</td>';
                    echo '<td>'. $key['preciocalidadextra'] . '</td>';
                    echo '<td>'. $key['preciocalidadprimera'] . '</td>';
					



                    echo '</tr>' ;
                    $j++;
if($j==20) break;
               
            }

              ?>
                </tbody>
            </table>
</div>
</div>

 </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>