<?php $__env->startSection('contenido'); ?>



		<div class="container">
<br>


<div  id="piechart">
 </div>



<?php

   $url="https://www.datos.gov.co/resource/kfq5-ygdu.json";

$json= file_get_contents($url);

$datos= json_decode($json, true);





    ?>
		<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>


<script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Nombre', 'Orden'],
          <?php

          $i=1;
                    foreach($datos as $r){ ?>[ <?php echo "'".$r['producto']."'"; ?>,   <?php  echo $r['cantidad']; ?>], <?php $i++; if($i==10) break; }?>

          
        ]);

        var options = {
          title: 'GRAFICA BOLETIN DIARIO DE PRECIOS DE VENTA MAYORISTA - CORPORACION DE ABASTOS DE BOGOTA. S.A CORABASTOS Producto vs Cantidad'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
    </script>


	
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="table-responsive">
			<table class="table table-striped table-bordered table-condensed table-hover">
                <thead>
                <tr>
                <th>Tipo Producto</th>
                    <th>Producto </th>
                    <th>Presentacion</th>
                    <th>Cantidad</th>
                    <th>Unidad</th>
                    <th>Precio Calidad Extra</th>
                    <th>Precio Calidad Primera</th>
				
                </tr>
                </thead>
                <tbody>
                <?php
$j=1;
            foreach ($datos as $key) {
			
                 echo '<tr>';
                    echo '<td>'. $key['tipoproducto'] . '</td>';
                    echo '<td>'. $key['producto'] . '</td>';
                    echo '<td>'. $key['presentacion'] . '</td>';
                    echo '<td>'. $key['cantidad'] . '</td>';
                     echo '<td>'. $key['unidad'] . '</td>';
                    echo '<td>'. $key['preciocalidadextra'] . '</td>';
                    echo '<td>'. $key['preciocalidadprimera'] . '</td>';
					



                    echo '</tr>' ;
                    $j++;
if($j==20) break;
               
            }

              ?>
                </tbody>
            </table>
</div>
</div>

 </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>